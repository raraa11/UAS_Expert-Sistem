from flask import Flask, render_template, url_for, request
import pickle
import numpy as np

app = Flask(__name__)

model_file = open("modelGNB.pkl", 'rb')
model = pickle.load(model_file, encoding='bytes')

@app.route("/")
def index():
    return render_template('index.html', hasil=0)

@app.route("/predict", methods=['POST'])
def predict():
    x1=float(request.form['pregnancy'])
    x2=float(request.form['glucose'])
    x3=float(request.form['tensi'])
    x4=float(request.form['skin'])
    x5=float(request.form['insulin'])
    x6=float(request.form['bmi'])
    x7=float(request.form['dpf'])
    x8=float(request.form['usia'])

    x = np.array([[x1,x2,x3,x4,x5,x6,x7,x8]])

    prediction = model.predict(x)
    if prediction == 0:
        output = "Normal"
    else:
        output = "Diabetes"
    
    return render_template('index.html', hasil=output, x1=x1, x2=x2, x3=x3, x4=x4, x5=x5, x6=x6, x7=x7, x8=x8)

if __name__ == "__main__":
    app.run(debug=True)