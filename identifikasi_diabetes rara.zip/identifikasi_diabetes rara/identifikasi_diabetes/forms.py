from wtforms import Form, StringField, validators, SubmitField, IntegerField, FloatField

class NewPresensiForm(Form):
    nama_presensi = StringField('Nama Presensi', [validators.DataRequired()])
    submit = SubmitField("Submit")