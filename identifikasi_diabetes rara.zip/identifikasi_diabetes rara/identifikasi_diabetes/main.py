from flask import Flask, render_template, url_for, request
from forms import NewPresensiForm
import pickle
import numpy as np
from flask_sqlalchemy import SQLAlchemy
from flask import flash
from sqlalchemy import select
from flask_wtf import FlaskForm
from wtforms_alchemy import QuerySelectMultipleField
from wtforms import widgets
import os
import numpy as np

app = Flask(__name__)

# model_file = open("modelGNB.pkl", 'rb')
# model = pickle.load(model_file, encoding='bytes')

#koneksi ke database
app.config["SQLALCHEMY_DATABASE_URI"] = 'mysql://root:''@localhost/test'
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False
SECRET_KEY = os.urandom(32)
app.config['SECRET_KEY']=SECRET_KEY

db = SQLAlchemy(app)

app.app_context().push()

# @app.route("/")
# def index():
#     return render_template('index.html', hasil=0)

@app.route("/index")
def index():
    return render_template('index.html')





# start
class Presensi(db.Model):
    kd_presensi = db.Column(db.Integer, primary_key=True)
    nama_presensi = db.Column(db.String(80), unique=True)

    def __init__(self, nama_presensi):
        self.nama_presensi=nama_presensi

    def __repr__(self):
        return f"{self.nama_presensi}. {self.kd_presensi}"

@app.route("/presensi")
def presensi():
    data = Presensi.query.order_by(Presensi.kd_presensi)
    return render_template('presensi.html', data=data)

@app.route("/insertPresensi", methods=['POST'])
def insertPresensi():
    form = NewPresensiForm()
    return render_template('formPresensi.html', form=form)

@app.route("/submitPen", methods=['POST','GET'])
def submitPen():
    form = NewPresensiForm(request.form)
    if form.validate():
        pen = Presensi(request.form['nama_presensi'])
        db.session.add(pen)
        try:
            db.session.commit()
            flash(f"Presensi {pen.nama_presensi} berhasil ditambahkan")
            return render_template ('formPresensi.html', presensi=pen.nama_presensi)  
        except Exception as e:
            db.session.rollback()
            flash(f"Presensi {pen.nama_presensi} gagal ditambahkan. Error {e}")
            return render_template  ('formPresensi.html', presensi=pen.nama_presensi)
    else:
        return "Invalidate form"

@app.route("/updatePresensi/<int:id>", methods=['POST','GET'])
def updatePresensi(id):
    form = NewPresensiForm()
    data_update = Presensi.query.get_or_404(id)
    if request.method == "POST":
        data_update.nama_presensi = request.form['nama_presensi']
        try:
            db.session.commit()
            flash(f"Update presensi berhasil!")
            return render_template('editPresensi.html', form=form, data_update=data_update)
        except Exception as e:
            db.session.rollback()
            flash(f"Update gagal! Error {e}")
            return render_template ('editPresensi.html', form=form, data_update=data_update)
    else:
        return render_template ('editPresensi.html', form=form, data_update=data_update)

@app.route("/deletePresensi/<int:id>", methods=['POST','GET'])
def deletePresensi(id):
    data_delete = Presensi.query.get_or_404(id)
    try:
        db.session.delete(data_delete)
        db.session.commit()

        #pesan notifikasi
        flash("Data prs berhasil dihapus!")

        #menampilkan sisa data
        presensi = Presensi.query.order_by(Presensi.kd_presensi)
        return render_template('presensi.html', data=presensi)
    except Exception as e:
        flash(f"Penghapusan data gagal! Error {e}")

        #menampilkan sisa data
        presensi = Presensi.query.order_by(Presensi.kd_presensi)
        return render_template('presensi.html', data=presensi)
# end





@app.route("/predict", methods=['POST'])
def predict():
    x1=float(request.form['pregnancy'])
    x2=float(request.form['glucose'])
    x3=float(request.form['tensi'])
    x4=float(request.form['skin'])
    x5=float(request.form['insulin'])
    x6=float(request.form['bmi'])
    x7=float(request.form['dpf'])
    x8=float(request.form['usia'])

    x = np.array([[x1,x2,x3,x4,x5,x6,x7,x8]])

    prediction = model.predict(x)
    if prediction == 0:
        output = "Normal"
    else:
        output = "Diabetes"
    
    return render_template('index.html', hasil=output, x1=x1, x2=x2, x3=x3, x4=x4, x5=x5, x6=x6, x7=x7, x8=x8)

if __name__ == "__main__":
    app.run(debug=True)